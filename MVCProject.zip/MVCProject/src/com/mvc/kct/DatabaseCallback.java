package com.mvc.kct;

public interface DatabaseCallback {
	
	void onDataEntrySuccess();
	
	void onDataEntryFailure(String error);

}
