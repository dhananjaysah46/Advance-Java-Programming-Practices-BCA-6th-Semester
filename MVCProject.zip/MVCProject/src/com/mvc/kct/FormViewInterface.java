package com.mvc.kct;

public interface FormViewInterface {
	
	void onSuccess();
	
	void onFailure(String reason);

}
