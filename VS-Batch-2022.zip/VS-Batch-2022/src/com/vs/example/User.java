package com.vs.example;

import java.io.Serializable;
import java.util.List;

/// pojo file 
/// plain old java object 
public class User implements Serializable{
	
	private String name;
	private String email;
	private List<String> names;
	
	public User() {}
	
	public User(String name, String email) {
		super();
		this.name = name;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	

}
