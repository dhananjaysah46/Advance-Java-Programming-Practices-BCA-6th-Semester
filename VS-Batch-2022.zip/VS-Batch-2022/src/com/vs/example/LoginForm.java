package com.vs.example;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class LoginForm extends JFrame implements ActionListener{
	
	private JLabel name,pass;
	private JTextField tName,tPass;
	private JButton submit;
	private JRadioButton male,female;
	private JCheckBox check;
	private JComboBox combo;
	// task JList, JPasswordField, JCheckBox
	
	public LoginForm() {
		
		setSize(800,800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		
		name = new JLabel("Name :");
		name.setBounds(100, 100, 100, 40);
		pass = new JLabel("Password :");
		pass.setBounds(100, 150, 100, 40);
		tName = new JTextField();
		tName.setBounds(200, 100, 100, 40);
		tPass = new JTextField();
		tPass.setBounds(200, 150, 100, 40);
		submit = new JButton("Submit");
		submit.setBounds(150, 200, 100, 40);
		submit.addActionListener(this);
		
		male = new JRadioButton("Male");
		male.setBounds(100, 250, 100, 40);
		female = new JRadioButton("Female");
		female.setBounds(200,250,100,40);
		ButtonGroup bg = new ButtonGroup();
		bg.add(male); bg.add(female);
		
		String [] cities = {"Kathmandu","Bhaktapur","Lalitpur","Banepa","Pokhara"};
		combo = new JComboBox<>(cities);
		combo.setBounds(300, 100, 200, 40);
		
		add(name); add(pass); add(tName); add(tPass); add(submit);
		add(male); add(female); add(combo);
		
		
		setVisible(true);
		
	}

	public static void main(String[] args) {
		new LoginForm();
		DBConnect db = new DBConnect();
		db.insertUser(new User("Name","Email"));
		db.retrieveUsers();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String name = tName.getText().toString();
		String pass = tPass.getText().toString();
		String city = combo.getSelectedItem().toString();
		String gender = "";
		if(male.isSelected()) gender = "male";
		else gender = "female";
		
		System.out.println(name +" "+pass +" "+city+" "+gender);
		
	}
}
