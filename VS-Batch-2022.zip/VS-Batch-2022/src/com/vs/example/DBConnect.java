package com.vs.example;

import java.sql.*;

import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

public class DBConnect {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	public DBConnect() {
		try {
		// 1
		Class.forName("com.mysql.cj.jdbc.Driver");
		// 2 url + db, user, pass
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/vs", 
				"root", "");
		String query = "create table if not exists users(id int primary key, "
				+ "name varchar(30), email varchar(30))";
		stmt = conn.createStatement();
		stmt.execute(query);
		}catch(Exception e) {
			System.out.println("Exception type " + e.toString());
		}
	}
	// retrieve datas and show them directly in TableModel and add it to the 
	// JFrame
	public TableModel retrieveDatas() {
		DefaultTableModel model;
		try {
			String sql = "select * from users";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			ResultSetMetaData metaData = rs.getMetaData();
			int count =  metaData.getColumnCount();
			String [] columnNames = new String[count];
			
			for(int column = 0; column <count; count++) {
				columnNames[column] = metaData.getColumnName(column);
			}
			
		 model = new DefaultTableModel(columnNames,0);
				while(rs.next()) {
					Object[] rows = new Object[count];
					for(int i=0; i<count; i++) {
						rows[i] = rs.getObject(i);
					}
					model.addColumn(rows);
				}		
			return model;
		}catch(Exception e) {
			
		}
		return new DefaultTableModel();
	}
	
	public void insertUser(User user) {
		try {
		String sql = "insert into users (id,name,email) values (?,?,?)";
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1,2);
		pstmt.setString(2, user.getName());
		pstmt.setString(3, user.getEmail());
		pstmt.executeUpdate();
		}catch(Exception e) {
			System.out.println(e.toString());
		}
	}
	
	public void retrieveUsers() {
		try {
		String sql = "select * from users";
		stmt = conn.createStatement();
		rs = stmt.executeQuery(sql);
		while(rs.next()) {
			String name = rs.getString("name");
			String email = rs.getString("email");
			System.out.println(name +" "+email);
		}
		}catch(Exception e) {
			System.out.println("Exception type :"+e.toString());
		}
	}

}
