package com.vs.example;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

public class BorderLayoutTest extends JFrame{
	private JButton east,west,north,south,center;
	
	public BorderLayoutTest() {
		setSize(800,800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		east = new JButton("East");
		west = new JButton("West");
		north = new JButton("North");
		south = new JButton("South");
		center = new JButton("Center");
		
		add(east,BorderLayout.EAST);
		add(west,BorderLayout.WEST);
		add(north,BorderLayout.NORTH);
		add(south,BorderLayout.SOUTH);
		add(center,BorderLayout.CENTER);
		setVisible(true);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BorderLayoutTest();

	}

}
