package com.kct.example;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class Menus extends JFrame{
	
	private JMenuBar menubar;
	private JMenu file,edit,view;
	private JMenuItem open,save,saveas;
	private ImageIcon image;
	
	public Menus() {
		setSize(800,800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		menubar = new JMenuBar();
		
		file = new JMenu("File");
		edit = new JMenu("Edit");
		view = new JMenu("View");
		
		menubar.add(file); menubar.add(edit); menubar.add(view);
		
		open = new JMenuItem("Open");
		save = new JMenuItem("Save");
		saveas = new JMenuItem("Save as");
		
		save.addKeyListener(new KeyListener() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub
				// When a short-cut is pressed, 
				// open the folder for file upload
				
			}
		});
		
		file.add(open); file.add(save); file.add(saveas);
		
		add(menubar,BorderLayout.NORTH);
		
		// adding image icon in the frame
		// or use ImageIO to load images from file
		String imagePath = "c:\\users\\images\\myimage.png";
		image = new ImageIcon(getClass().getResource(imagePath));
		JLabel label = new JLabel();
		label.setIcon(image);
		add(label,BorderLayout.CENTER);
		
		setVisible(true);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Menus();

	}

}
