package com.college;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SetCookiesServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, 
			HttpServletResponse resp) 
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
		Cookie userCookie = new Cookie("username","Hello User");
		userCookie.setMaxAge(60 * 60);
		resp.addCookie(userCookie);
		resp.setContentType("text/html");
		resp.getWriter().println("Cookie has been set");
	}

}
