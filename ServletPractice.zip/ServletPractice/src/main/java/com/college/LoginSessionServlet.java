package com.college;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginSessionServlet extends HttpServlet{
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
		
		String user = req.getParameter("username");
		String pass = req.getParameter("password");
		
		if("admin".equals(user) && "1234".equals(pass)) {
			HttpSession session = req.getSession();
			session.setAttribute("username", user);
			resp.sendRedirect("dashboard.html");
		}else {
			resp.getWriter().println("Login Failed");
		}
	}

}
