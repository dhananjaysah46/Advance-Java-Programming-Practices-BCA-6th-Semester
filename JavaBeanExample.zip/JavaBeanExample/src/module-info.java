/**
 * 
 */
/**
 * 
 */
module JavaBeanExample {
	requires java.desktop;
}