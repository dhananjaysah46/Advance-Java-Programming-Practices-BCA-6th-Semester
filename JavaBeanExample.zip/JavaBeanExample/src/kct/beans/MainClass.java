package kct.beans;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserBean user = new UserBean();
		
		user.setEmail("kct@gmail.com");
		user.setName("KCT College");
		user.setAge(20);
		
		System.out.println(user.getName() +", "+ user.getEmail()+", "+user.getAge());

	}

}
